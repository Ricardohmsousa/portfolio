from openai import OpenAI
import json

client = OpenAI(
    api_key="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",
)

# update this to be an actual function
def get_current_weather(location, unit="fahrenheit"):
    """Get the current weather in a given location"""
    weather_info = {
        "location": location,
        "temperature": "72",
        "unit": unit,
        "forecast": ["sunny", "windy"],
    }
    return json.dumps(weather_info)


assistant = client.beta.assistants.retrieve("asst_keWqWObB2DahzbLW5obPHnDr")

# Create a new thread
thread = client.beta.threads.create()
user_input=""
while user_input!="q":
    # Get user input
    user_input = input("You: ")

    # Send user input as a message
    user_message = client.beta.threads.messages.create(
        thread_id=thread.id,
        role="user",
        content=user_input,
    )

    # Run the assistant
    run = client.beta.threads.runs.create(thread_id=thread.id, assistant_id=assistant.id)

    while run.status != "completed":

        run = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)
        if(run.status=="requires_action" and run.required_action.type=="submit_tool_outputs"):
            print("chega aqui")
            weatherInfo=get_current_weather(run.required_action.submit_tool_outputs.tool_calls[0].function.)
            run = client.beta.threads.runs.submit_tool_outputs(
              thread_id=thread.id,
              run_id=run.id,
              tool_outputs=[
                  {
                    "tool_call_id": run.required_action.submit_tool_outputs.tool_calls[0].id,
                    "output": weatherInfo,
                  }
                ]
            )
        print(run.status )

    # Display the conversation
    messages = client.beta.threads.messages.list(thread_id=thread.id)



    print(messages.data[0].role, ":", messages.data[0].content[0].text.value)

