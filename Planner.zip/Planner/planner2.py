import vertexai
from vertexai.language_models import ChatModel
from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

vertexai.init(project="data-avatar-406114", location="us-central1")

app = FastAPI()
chat_models = {}  # Dictionary to store different chat instances


class ChatRequest(BaseModel):
    chat_id: str
    message: str


@app.post("/chat")
async def chat_endpoint(request: Request, chat_data: ChatRequest):
    try:
        chat_id = chat_data.chat_id
        message = chat_data.message

        # Check if the chat_id already has a chat instance
        if chat_id not in chat_models:
            # If not, create a new chat instance
            chat_models[chat_id] = ChatModel.from_pretrained("chat-bison")

        # Get the chat instance for the given chat_id
        chat_model = chat_models[chat_id]

        # Define parameters
        parameters = {
            "candidate_count": 1,
            "max_output_tokens": 1024,
            "temperature": 0.2,
            "top_p": 0.8,
            "top_k": 40
        }

        # Start chat with the given context
        chat = chat_model.start_chat(context="""Usa o google maps para calcular a melhor rota. Responde com um json com os seguintes parametros geojson - geojson da rota com ponto de inicio, ponto de fim e pontos intermédios) steps - array de strings com os passos para chegar ao destino
solution - resumo da trajeto. Exemplo : geojson": {
    "type": "FeatureCollection",
    "features": [
      {
        "type": "Feature",
        "geometry": {
          "type": "Point",
          "coordinates": [longitude_inicio, latitude_inicio]
        },
        "properties": {
          "name": "Ponto de Início"
        }
      },
      // ... outros pontos intermédios ...
      {
        "type": "Feature",
        "geometry": {
          "type": "Point",
          "coordinates": [longitude_fim, latitude_fim]
        },
        "properties": {
          "name": "Ponto de Fim"
        }
      }
    ]
  },
  "steps": [
    "Comece indo para o sul na Rua A",
    "Vire à direita na Rua B",
    // ... outras instruções ...
    "Chegada ao destino"
  ],
  "solution": {
    "summary": "Chegue ao destino em 30 minutos, percorrendo uma distância de 10 km."
  }
}""")

        # Send message and get response 
        response = chat.send_message(message, **parameters)

        # Return the response as JSON
        return {"response": response.text}

    except Exception as e:
        # Handle any exceptions that might occur
        raise HTTPException(status_code=500, detail=str(e))
